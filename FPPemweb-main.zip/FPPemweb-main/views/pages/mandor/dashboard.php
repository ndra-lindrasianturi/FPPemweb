<h2>Dashboard Mandor</h2>
<p>Selamat datang, Mandor!</p>

<?php include __DIR__ . "/../../components/alert.php" ?>