INSERT INTO users (username, phone_number, role) VALUES
('Admin', '08113491880', 'admin'),
('Mandor', '085850442064', 'mandor');
