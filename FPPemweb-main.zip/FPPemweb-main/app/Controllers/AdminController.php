<?php
class AdminController
{
  public static function dashboard()
  {
    view('pages/admin/dashboard');
  }
}
