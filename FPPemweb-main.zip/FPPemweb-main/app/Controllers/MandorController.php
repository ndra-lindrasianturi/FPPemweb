<?php
class MandorController
{
  public static function dashboard()
  {
    view('pages/mandor/dashboard');
  }
}
